<?php
	/**
	* Hello World php
	* @author Professor José de Assis
	*/
	echo "Hello World";
	phpinfo();
?>
