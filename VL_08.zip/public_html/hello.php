<?php
	/**
	* Hello World php
	* @author Victor Guilherme
	*/
	echo "Hello World";
	phpinfo();
?>
